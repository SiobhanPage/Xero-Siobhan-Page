﻿global using Infrastructure.Persistence.Repositories;
global using Infrastructure.Persistence.Models;
