﻿using AutoFixture;
using Infrastructure.Persistence.Models;
using Infrastructure.Persistence.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using WebApi.Controllers;
using WebApi.Models;

namespace WebApi.UnitTests
{
    [TestFixture]
    public class ProductControllerTests
    {
        private Mock<ILogger<ProductController>> _mockLogger;
        private Mock<IProductRepository<Product>>  _mockRepository;
        private ProductController? _mockController;
        private Fixture _fixture;

        [SetUp]
        public void SetUp()
        {
            _mockLogger = new Mock<ILogger<ProductController>>();
            _mockRepository = new Mock<IProductRepository<Product>>();
            _fixture = new Fixture();
        }

        [Test]
        public async Task GetAll_WhenCalled_ReturnOkResult()
        { 
            // Arrange
            var products = _fixture.CreateMany<Product>(3).ToList();

            _mockRepository.Setup(repo => repo.ListAllAsync()).ReturnsAsync(products);
            _mockController = new ProductController(_mockLogger.Object, _mockRepository.Object);

            // Act
            var result = await _mockController.GetAll();

            // Assert
            Assert.That(result.Result, Is.Not.Null);
            Assert.That(result.Result, Is.TypeOf<OkObjectResult>());
        }

        [Test]
        public async Task GetProductsByName_WhenCalled_ReturnOkResult()
        {
            // Arrange
            string name = _fixture.Create<string>();
            var products = _fixture.CreateMany<Product>(3).ToList();

            _mockRepository.Setup(repo => repo.SearchByNameAsync(It.IsAny<string>())).ReturnsAsync(products);
            _mockController = new ProductController(_mockLogger.Object, _mockRepository.Object);

            // Act
            var result = await _mockController.GetProductsByName(name);

            // Assert
            Assert.That(result.Result, Is.Not.Null);
            Assert.That(result.Result, Is.TypeOf<OkObjectResult>());
        }

        [Test]
        public async Task GetProduct_WhenCalled_ReturnOkResult()
        {
            var product = _fixture.Create<Product>();
            var guid = _fixture.Create<Guid>();

            _mockRepository.Setup(repo => repo.GetByIdAsync(It.IsAny<Guid>())).ReturnsAsync(product);
            _mockController = new ProductController(_mockLogger.Object, _mockRepository.Object);

            // Act
            var result = await _mockController.GetProduct(guid);

            // Assert
            Assert.That(result.Result, Is.Not.Null);
            Assert.That(result.Result, Is.TypeOf<OkObjectResult>());
        }

        [Test]
        public async Task GetProduct_IdDoesNotExist_ReturnNotFoundResult()
        {
            // Arrange
            var guid = _fixture.Create<Guid>();

            _mockRepository.Setup(repo => repo.GetByIdAsync(guid)).Returns(Task.FromResult<Product?>(null));
            _mockController = new ProductController(_mockLogger.Object, _mockRepository.Object);

            // Act
            var result = await _mockController.GetProduct(guid);

            // Assert
            Assert.That(result.Result, Is.Not.Null);
            Assert.That(result.Result, Is.TypeOf<NotFoundResult>());
        }

        [Test]
        public async Task CreateProduct_WhenCalled_ReturnCreatedAtActionResult()
        {
            // Arrange
            var product = _fixture.Create<ProductDto>();

            _mockRepository.Setup(repo => repo.AddAsync(It.IsAny<Product>()));
            _mockController = new ProductController(_mockLogger.Object, _mockRepository.Object);

            // Act
            var result = await _mockController.CreateProduct(product);

            // Assert
            Assert.That(result.Result, Is.Not.Null);
            Assert.That(result.Result, Is.TypeOf<CreatedAtActionResult>());
        }

        [Test]
        public async Task UpdateProduct_WhenCalled_ReturnNoContentResult()
        {
            // Arrange
            var guid = Guid.NewGuid();
            _fixture.Customize<ProductDto>(p => p.With(x => x.Guid, guid));
            var product = _fixture.Create<ProductDto>();

            _mockRepository.Setup(repo => repo.UpdateAsync(It.IsAny<Product>()));
            _mockController = new ProductController(_mockLogger.Object, _mockRepository.Object);

            // Act
            var result = await _mockController.UpdateProduct(guid, product);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.TypeOf<NoContentResult>());
        }

        [Test]
        public async Task UpdateProduct_IdParamsDoNotMatch_ReturnBadRequestResult()
        {
            // Arrange
            var guid = Guid.NewGuid();
            var product = _fixture.Create<ProductDto>();

            _mockRepository.Setup(repo => repo.UpdateAsync(It.IsAny<Product>()));
            _mockController = new ProductController(_mockLogger.Object, _mockRepository.Object);

            // Act
            var result = await _mockController.UpdateProduct(guid, product);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.TypeOf<BadRequestObjectResult>());
        }

        [Test]
        public async Task DeleteProduct_WhenCalled_ReturnNoContent()
        {
            // Arrange
            var guid = Guid.NewGuid();
            _fixture.Customize<Product>(p => p.With(x => x.Guid, guid));
            var product = _fixture.Create<Product>();

            _mockRepository.Setup(repo => repo.GetByIdAsync(guid)).ReturnsAsync(product);
            _mockController = new ProductController(_mockLogger.Object, _mockRepository.Object);

            // Act
            var result = await _mockController.DeleteProduct(guid);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.TypeOf<NoContentResult>());
        }

        [Test]
        public async Task DeleteProduct_IdDoesNotExist_ReturnNotFound()
        {
            // Arrange
            var guid = _fixture.Create<Guid>();
            var product = _fixture.Create<Product>();

            _mockRepository.Setup(repo => repo.GetByIdAsync(guid)).Returns(Task.FromResult<Product?>(null));
            _mockController = new ProductController(_mockLogger.Object, _mockRepository.Object);

            // Act
            var result = await _mockController.DeleteProduct(guid);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result, Is.TypeOf<NotFoundResult>());
        }
    }
}
