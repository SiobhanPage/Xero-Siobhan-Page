﻿/*
  Description	Save a product option.
				If the product option already exists, update the existing product option otherwise add a new product option.

  Debug
  EXEC [dbo].[usp_SaveProductOption] '0643CCF0-AB00-4862-B3C5-40E2731ABCC9', '8F2E9176-35EE-4F0A-AE55-83023D2DB1A3', 'Blue', 'Blue Samsung Galaxy S7'
*/
CREATE PROCEDURE [dbo].[usp_SaveProductOption]
(
	@Guid 			UNIQUEIDENTIFIER,
	@ProductGuid	UNIQUEIDENTIFIER,
	@Name			NVARCHAR (100),
	@Description    NVARCHAR (500) = NULL
)
AS
BEGIN
IF EXISTS(SELECT 1 FROM dbo.ProductOption WHERE [Guid] = @Guid)
	BEGIN
		UPDATE [dbo].[ProductOption]
		SET 	[Name] = @Name
				, [Description] = @Description
		WHERE 	[Guid] = @Guid
	END
ELSE
	BEGIN
		INSERT INTO [dbo].[ProductOption] ([Guid], [ProductGuid], [Name], [Description])
		VALUES (@Guid, @ProductGuid, @Name, @Description)
	END
END