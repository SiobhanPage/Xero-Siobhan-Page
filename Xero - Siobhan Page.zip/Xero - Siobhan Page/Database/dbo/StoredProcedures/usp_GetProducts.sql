﻿/*
  Description	Retrieve a list of products.
				Return all records if a parameter has not been provided or both parameters are null.
				Return matching record if the Guid parameter has been provided.
				Return matching records if a Name parameter has been provided.
				Return matching records for Name and Guid if both parameters have been provided.

  Debug
  EXEC [dbo].[usp_GetProducts] NULL
  EXEC [dbo].[usp_GetProducts] '8f2e9176-35ee-4f0a-ae55-83023d2db1a3', NULL
  EXEC [dbo].[usp_GetProduct] NULL, 'sAmsung'
  EXEC [dbo].[usp_GetProducts] '8f2e9176-35ee-4f0a-ae55-83023d2db1a3', 'Galaxy'
*/
CREATE PROCEDURE [dbo].[usp_GetProducts]
(
	@Guid	UNIQUEIDENTIFIER = NULL,
	@Name	NVARCHAR(100) = NULL
)
AS
BEGIN
	
	SELECT 	[Guid],
			[Name],
			[Description],
			[Price],
			[DeliveryPrice]
	FROM	[dbo].[Product]
	WHERE   [Guid] = COALESCE(@Guid, [Guid])
	AND		(@Name IS NULL OR LOWER([Name]) LIKE '%' + LOWER(@Name) +'%')

END
GO

