﻿/*
  Description	Delete a product option. 

  Debug
  EXEC [dbo].[usp_DeleteProductOption] '0643CCF0-AB00-4862-B3C5-40E2731ABCC9'
*/
CREATE PROCEDURE [dbo].[usp_DeleteProductOption]
(
	@Guid 		UNIQUEIDENTIFIER
)
AS
BEGIN

	DELETE FROM [dbo].[ProductOption] WHERE [Guid] = @Guid

END

GO

