﻿/*
  Description	Save a product.
				If the product already exists, update the existing product otherwise add a new product.

  Debug
  EXEC [dbo].[usp_SaveProduct] '34c57f22-4ddb-4fc4-ae7e-b2d2450f1e82', 'Samsung Galaxy S5', 'Older mobile product from Samsung', 125.99, 16.99
*/
CREATE PROCEDURE [dbo].[usp_SaveProduct]
(
	@Guid 			UNIQUEIDENTIFIER,
	@Name			NVARCHAR (100),
	@Description    NVARCHAR (500) = NULL,
	@Price         	DECIMAL (18, 2),
 	@DeliveryPrice  DECIMAL (18, 2) 
)
AS
BEGIN
IF EXISTS(SELECT 1 FROM dbo.Product WHERE [Guid] = @Guid)
	BEGIN
		UPDATE [dbo].[Product]
		SET 	[Name] = @Name
				, [Description] = @Description
				, [Price] = @Price
				, [DeliveryPrice] = @DeliveryPrice
		WHERE 	[Guid] = @Guid
	END
ELSE
	BEGIN
		INSERT INTO [dbo].[Product] ([Guid], [Name], [Description], [Price], [DeliveryPrice])
		VALUES (@Guid, @Name, @Description, @Price, @DeliveryPrice)
	END
END