﻿/*
  Description	Retrieve a list of product options.
				Return all records if a parameter has not been provided or both parameters are null.
				Return all product options associated with a Product if the ProductGuid parameter has been provided.
				Return matching product option if the Guid parameter has been provided.

  Debug
  EXEC [dbo].[usp_GetProductOptions] NULL
  EXEC [dbo].[usp_GetProductOptions] '8f2e9176-35ee-4f0a-ae55-83023d2db1a3', NULL
  EXEC [dbo].[usp_GetProductOptions] NULL, 'a21d5777-a655-4020-b431-624bb331e9a2'
*/
CREATE PROCEDURE [dbo].[usp_GetProductOptions]
(
	@ProductGuid	UNIQUEIDENTIFIER = NULL,
	@Guid			UNIQUEIDENTIFIER = NULL
)
AS
BEGIN
	
	SELECT 	[Id],
			[Guid],
			[ProductGuid], 
			[Name],
			[Description]
	FROM	[dbo].[ProductOption]
	WHERE	[Guid] = COALESCE(@Guid, [Guid])
	AND		[ProductGuid] = COALESCE(@ProductGuid, [ProductGuid])

END
GO

