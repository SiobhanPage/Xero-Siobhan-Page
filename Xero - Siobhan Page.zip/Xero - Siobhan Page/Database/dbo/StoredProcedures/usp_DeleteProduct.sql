﻿/*
  Description	Delete a product. 
				Delete all associated product options before deleting the product.
				Wrap in a transaction to protect the data integrity.

  Debug
  EXEC [dbo].[usp_DeleteProduct] '34c57f22-4ddb-4fc4-ae7e-b2d2450f1e82'
*/
CREATE PROCEDURE [dbo].[usp_DeleteProduct]
(
	@Guid 		UNIQUEIDENTIFIER
)
AS
BEGIN

	BEGIN TRY
		BEGIN TRAN

		DELETE FROM [dbo].[ProductOption] WHERE ProductGuid = @Guid
		DELETE FROM [dbo].[Product] WHERE [Guid] = @Guid
			
		COMMIT TRAN
	END TRY

	BEGIN CATCH
		/* Rollback the transaction if necessary */
		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION

		EXEC [dbo].[usp_ReRaiseError] 'An error occurred when attempting to delete a product' 

	END CATCH

END
GO

