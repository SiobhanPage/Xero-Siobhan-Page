﻿/* Description	Reraises the current error when called from a catch block
 
   Debug		[dbo].[usp_ReRaiseError] 'Custom Error Message' 
 */
CREATE PROCEDURE [dbo].[usp_ReRaiseError] 
	@ErrorMessage	VARCHAR(500)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @ErrorNumber INT,
			@ErrorSeverity INT,
			@ErrorState INT

	SELECT
		@ErrorNumber = ERROR_NUMBER(),
		@ErrorSeverity = ERROR_SEVERITY(),
		@ErrorState = ERROR_STATE(),
		@ErrorMessage = @ErrorMessage + ': ' + ERROR_MESSAGE()

	RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState)

END

GO

