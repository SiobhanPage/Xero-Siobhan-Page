﻿
CREATE TABLE [dbo].[Product] (
    [Id]            BIGINT IDENTITY(1,1) NOT NULL,
    [Guid]          UNIQUEIDENTIFIER NOT NULL,
    [Name]          NVARCHAR (100)   NOT NULL,
    [Description]   NVARCHAR (500)   NULL,
    [Price]         DECIMAL (18, 2)  NOT NULL,
    [DeliveryPrice] DECIMAL (18, 2)  NOT NULL,
    CONSTRAINT [PK_Product_Id] PRIMARY KEY CLUSTERED ([Id] ASC)
);
GO

CREATE UNIQUE NONCLUSTERED INDEX [IX_Product_Guid] ON [dbo].[Product] ([Guid] Asc)
GO

CREATE NONCLUSTERED INDEX [IX_Product_Name] ON [dbo].[Product] ([Name] Asc)
GO
