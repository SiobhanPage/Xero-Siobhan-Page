﻿
CREATE TABLE [dbo].[ProductOption] (
    [Id]          BIGINT IDENTITY(1,1) NOT NULL,
    [Guid]        UNIQUEIDENTIFIER NOT NULL,
    [ProductGuid] UNIQUEIDENTIFIER NOT NULL,
    [Name]        NVARCHAR (100)   NOT NULL,
    [Description] NVARCHAR (500)   NULL,
    CONSTRAINT [PK_ProductOption_Id] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ProductOption_ProductGuid] FOREIGN KEY ([ProductGuid]) REFERENCES Product([Guid])
);
GO

CREATE UNIQUE NONCLUSTERED INDEX [IX_ProductOption_Guid] ON [dbo].[ProductOption] ([Guid] Asc)
GO

CREATE NONCLUSTERED INDEX [IX_ProductOption_ProductGuid] ON [dbo].[ProductOption] ([ProductGuid] Asc)
GO
