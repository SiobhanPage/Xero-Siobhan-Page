
The first change I decided to make was to upgrade the solution from .NET Framework 4.5.2 to .NET 8.0.

There were several reasons behind this:
1. .NET Framework 4.5.2 is no longer supported by Microsoft.
2. The risk was minimal considering the project size and the fact that it had no dependencies on incompatible third party libraries.
3. There were many benefits to be gained: .NET 8.0 is a Long Term Support release with significant performance improvements as well as enhanced support for integration with cloud platforms. In terms of this particular project, I was immediately able to make use of the support for Swagger and also to take advantage of the built-in dependency injection. The support for dependency injection is a big bonus in terms of creating loosely coupled applications which are easier to maintain and test.

Taking a look at the original project, I identified several issues which I attempted to address.

Web API Project

1. The model classes [Products, Product, ProductOptions and ProductOption] are tightly coupled to a specific data access implementation. This breaks several design principles:

* The single responsibility principle – they are not just models but are also responsible for the data access code.
* The open/closed principle – any changes to the data access implementation will also require changes to these classes.
* The dependency inversion principle – the classes should not be dependent on a specific implementation by another resource. We need to supply the dependencies of the classes from the outside. We also need to make these dependencies abstractions (i.e. use interfaces) in order to make the classes flexible, loosely coupled and testable.

Therefore, I decided to decouple these classes from external resources. I extracted all the database access code into two classes – the ProductRepository and ProductOptionRepository classes. For further isolation I created a separate Infrastructure project which contains all the code touching external resources. The entirety of the data access code has been encapsulated within the Infrastructure project. 

Each repository class implements an interface. The Web API project talks solely to these interfaces (IProductRepository and IProductOptionRepository) and not to the concrete implementation of the repositories. So now the Web API is dependent only on these interfaces and as such doesn’t need to know anything about the data access code implementation. I have used SQL and Dapper for data access but further down the road we could change this to use Entity Framework or change the database to be CosmosDB without affecting the Web API. Programming against interfaces allows us to provide different implementations at different times so the consuming class is not dependent on a specific implementation. Using dependency injection, we can supply the dependencies of a class from the outside which makes the classes loosely-coupled. It also makes them testable as you can provide a fake implementation for unit tests. This keeps our Web API project clean and simple and we can also reuse the Infrastructure class library in other projects.

2. The data access code in the existing project combines input directly with SQL statements. This exposes the API to the risk of SQL injection.

I decided to use parameterised stored procedures in the database instead of dynamic SQL statements for these reasons:

* Enhanced security. Stored procedures prevent SQL injection as the input parameters are treated as a text value rather than as a command. 
  You can also restrict access/permissions to the database by granting EXECUTE permissions just to the stored procedures.
* Improved performance - they are compiled and optimised by SQL so run a bit faster than adhoc SQL statements.
* Easier to track down and fix performance issues using SQL Server Profiler.
* They are easy to maintain and reuse.
* Using stored procedures keeps the code clean and enables a separation of concerns.

3. I noticed some inefficient logic in the data access code which would result in multiple unnecessary round trips to the database. For example, to get a list of Products a list of Ids is retrieved from the database and then looped over needing another trip to the database to retrieve the details for each Id. 

This could be performed more simply and efficiently with a single query which gets all the data needed in one hit to the database which is why the stored procedures have been written to return one resultset respectively for the Product and ProductOption details.

4. The Products controller also contains all the methods for Product options. This breaks the single responsibility principle.

I decided to create a separate ProductOptions controller and move these methods to make it cleaner and easier to maintain.

5. Error handling: I was able to see only a couple of specific instances of error handling (in the Get() and GetOption() methods) and no global error handling.

I implemented a global error handler and included some specific error return results from the controllers in obvious cases e.g. on the Delete it returns NotFound() if the id doesn’t exist in the database. 

6. No use of async: I updated all controller methods to use async for data retrieval to avoid locking the API while we call to the SQL database.

7. DTOs - The controller methods expose the entire data model to the client. It would be better to provide a DTO in order to hide the properties clients aren’t supposed to view, reduce payload and prevent over-posting.
I’ve created DTO objects to expose to the client. In the case of the Create and Update methods for Product Options it’s useful to hide some of the properties the user doesn’t need to see. In a production app I would use AutoMapper to map between the data models and the DTOs. Here I’ve just used a simple class with a couple of mapping methods.

8. No validation: I added some validation attributes to the Product and ProductOption DTO objects. 
I didn't add any checking for ModelState.IsValid in the methods because for .NET 8 Web API controllers don't have to check ModelState.IsValid if they have the [ApiController] attribute. An automatic HTTP 400 response containing error details is returned when model state is invalid.

9. No Logging: With .NET 8.0 the default logger is injected automatically into the controller which makes it easy to use. I haven't configured logging to a file or database as this would be dependent on requirements.

10. No tests: I've written some unit tests for the Product controller but ran out of time to include any for Product options. Ideally there would also be a project containing integration tests.

11. No authentication or authorization: I haven't attempted to implement this as it would need to be dependent on requirements and also take into account how the application is being hosted.

12. No caching: Adding this might be something to consider if we need to enhance performance in the future.

Database

1. The database file is included directly within the Web API project.

As we don’t want the API project to be tightly coupled with any external dependencies, I created a separate SQL Server Database Project to host the database.

2. Database Tables: For both tables the primary key is a UniqueIdentifier (GUID) with a clustered index. 
There is a lot of debate about the performance concerns of using a GUID as a primary key but even more significantly the impact of this also being the clustering key. A clustered index defines the order in which data is physically stored in a table. As a GUID is non-sequential this can lead to page and index fragmentation and create performance overhead with additional cost for inserts and no discernible gain for queries.

I decided to remove the clustered index from the GUID field. As it’s better to have a clustered index on the table for performance I then considered which field I could use as the clustered index. There was no obvious candidate as none of the current fields could be guaranteed to be unique. For this reason, I added a BIGINT IDENTITY column as the PK with a clustered index on the Product and ProductOption tables. I thought about linking to this field as the foreign key on ProductOption as it would improve performance for joins (joining on BIGINT not GUID) but as there are no requirements for joins and for the sake of simplicity, I decided to link directly to the GUID field for the foreign key.

Product Table Changes:
1 I created a BIGINT IDENTITY Id field with a clustered index as the primary key.
2 I renamed the UNIQUEIDENTIFIER Id field to Guid.  
3 I created a unique non-clustered index on the Guid field as this will be commonly used in queries. 
4 I created a non-clustered index on the Name field as users will search against this column. 
5 I changed the name of the table to 'Product' in order to keep the naming convention consistent with the ProductOption table which uses singular over plural. (using the plural would also be fine but consistency is key).

ProductOption Table Changes:
As for the Products table points 1-3.
4 I changed the name of the ProductId field to ProductGuid (to be more explicit about the type).
5 I made the ProductGuid field a foreign key (linked to the Guid field on the Products table) to ensure referential integrity.
6 I created a non-clustered index on the ProductGuid field as this will be commonly used in queries.




