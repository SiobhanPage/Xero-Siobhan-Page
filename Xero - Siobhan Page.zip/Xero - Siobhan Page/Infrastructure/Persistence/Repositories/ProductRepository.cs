﻿using Infrastructure.Persistence.DbAccess;
using Infrastructure.Persistence.Models;

namespace Infrastructure.Persistence.Repositories
{
    public class ProductRepository : IProductRepository<Product>
    {
        private readonly IDataAccess _dataAccess;

        public ProductRepository(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }
        public async Task<IEnumerable<Product>> ListAllAsync()
        {
            string procName = Constants.StoredProcedures.GetProducts;

            return await _dataAccess.GetData<Product, dynamic>(procName, new { });
        }

        public async Task<IEnumerable<Product>> SearchByNameAsync(string name)
        {
            string procName = Constants.StoredProcedures.GetProducts;

            return await _dataAccess.GetData<Product, dynamic>(procName, new { Name = name });
        }

        public async Task<Product?> GetByIdAsync(Guid guid)
        {
            string procName = Constants.StoredProcedures.GetProducts;

            var results = await _dataAccess.GetData<Product, dynamic>(procName, new { Guid = guid });
            return results.FirstOrDefault();
        }

        public async Task AddAsync(Product entity)
        {
            string procName = Constants.StoredProcedures.SaveProduct;

            await _dataAccess.SaveData<Product, dynamic>(procName, entity);
        }
        public async Task UpdateAsync(Product entity)
        {
            string procName = Constants.StoredProcedures.SaveProduct;

            await _dataAccess.SaveData<Product, dynamic>(procName, entity);
        }

        public async Task DeleteAsync(Guid guid)
        {
            string procName = Constants.StoredProcedures.DeleteProduct;

            await _dataAccess.SaveData<Product, dynamic>(procName, new { Guid = guid });
        }
    }
}
