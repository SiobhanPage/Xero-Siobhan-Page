﻿using Infrastructure.Persistence.Models;

namespace Infrastructure.Persistence.Repositories
{
    public interface IBaseRepository<T> where T : IBaseEntity
    {
        Task<IEnumerable<T>> ListAllAsync();
        Task<T?> GetByIdAsync(Guid guid);
        Task AddAsync(T entity);
        Task UpdateAsync(T entity);
        Task DeleteAsync(Guid guid);
    }

    public interface IProductRepository<T> : IBaseRepository<T> where T : IBaseEntity
    {
        Task<IEnumerable<T>> SearchByNameAsync(string name);
    }

    public interface IProductOptionRepository<T> : IBaseRepository<T> where T : IBaseEntity
    {
        Task<IEnumerable<T>> SearchByProductIdAsync(Guid productGuid);
        Task<ProductOption?> GetByProductAndOptionIdAsync(Guid productGuid, Guid guid);
    }
}
