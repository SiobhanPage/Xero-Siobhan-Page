﻿using Infrastructure.Persistence.DbAccess;
using Infrastructure.Persistence.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Infrastructure.Persistence.Repositories
{
    public class ProductOptionRepository : IProductOptionRepository<ProductOption>
    {
        private readonly IDataAccess _dataAccess;

        public ProductOptionRepository(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }
        public async Task<IEnumerable<ProductOption>> ListAllAsync()
        {
            string procName = Constants.StoredProcedures.GetProductOptions;

            return await _dataAccess.GetData<ProductOption, dynamic>(procName, new { });
        }

        public async Task<IEnumerable<ProductOption>> SearchByProductIdAsync(Guid productGuid)
        {
            string procName = Constants.StoredProcedures.GetProductOptions;

            return await _dataAccess.GetData<ProductOption, dynamic>
                         (procName, new { ProductGuid = productGuid });
        }

        public async Task<ProductOption?> GetByIdAsync(Guid guid)
        {
            string procName = Constants.StoredProcedures.GetProductOptions;

            var results = await _dataAccess.GetData<ProductOption, dynamic>
                                (procName, new { Guid = guid });

            return results.FirstOrDefault();
        }

        public async Task<ProductOption?> GetByProductAndOptionIdAsync(Guid productGuid, Guid guid)
        {
            string procName = Constants.StoredProcedures.GetProductOptions;

            var results = await _dataAccess.GetData<ProductOption, dynamic>
                                (procName, new { ProductGuid = productGuid, Guid = guid });

            return results.FirstOrDefault();
        }

        public async Task AddAsync(ProductOption entity)
        {
            string procName = Constants.StoredProcedures.SaveProductOption;

            await _dataAccess.SaveData<ProductOption, dynamic>(procName, entity);
        }

        public async Task UpdateAsync(ProductOption entity)
        {
            string procName = Constants.StoredProcedures.SaveProductOption;

            await _dataAccess.SaveData<ProductOption, dynamic>(procName, entity);
        }

        public async Task DeleteAsync(Guid guid)
        {
            string procName = Constants.StoredProcedures.DeleteProductOption;

            await _dataAccess.SaveData<ProductOption, dynamic>(procName, new { Guid = guid });
        }
    }
}
