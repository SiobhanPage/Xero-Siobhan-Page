﻿
namespace Infrastructure.Persistence
{
    public static class Constants
    {
        public static class StoredProcedures
        {
            public const string GetProducts = "dbo.usp_GetProducts";
            public const string SaveProduct = "dbo.usp_SaveProduct";
            public const string DeleteProduct = "dbo.usp_DeleteProduct";

            public const string GetProductOptions = "dbo.usp_GetProductOptions";
            public const string SaveProductOption = "dbo.usp_SaveProductOption";
            public const string DeleteProductOption = "dbo.usp_DeleteProductOption";
        }
    }
}
