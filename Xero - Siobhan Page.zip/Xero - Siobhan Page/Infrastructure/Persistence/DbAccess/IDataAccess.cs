﻿
namespace Infrastructure.Persistence.DbAccess
{
    public interface IDataAccess
    {
        Task<IEnumerable<T>> GetData<T, P>(string storedProcedure, P parameters, string connectionId = "Default");
        Task SaveData<T, P>(string storedProcedure, P parameters, string connectionId = "Default");
    }
}