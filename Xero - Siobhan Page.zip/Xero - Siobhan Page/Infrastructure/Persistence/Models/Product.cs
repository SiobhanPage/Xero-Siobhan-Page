﻿
namespace Infrastructure.Persistence.Models
{
    public class Product : IBaseEntity
    {
        public Guid Guid { get; set; }

        public required string Name { get; set; }

        public string? Description { get; set; }

        public decimal Price { get; set; }

        public decimal DeliveryPrice { get; set; }
    }
}
