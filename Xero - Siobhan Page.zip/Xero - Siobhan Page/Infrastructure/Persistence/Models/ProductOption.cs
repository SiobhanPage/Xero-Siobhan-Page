﻿
namespace Infrastructure.Persistence.Models
{
    public class ProductOption : IBaseEntity
    {
        public Guid Guid { get; set; }

        public Guid ProductGuid { get; set; }

        public required string Name { get; set; }

        public string? Description { get; set; }
    }
}
