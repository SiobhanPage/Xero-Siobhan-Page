﻿namespace Infrastructure.Persistence.Models
{
    public interface IBaseEntity
    {
        public Guid Guid { get; set; }
    }
}
